package com.lokesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContractFApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContractFApplication.class, args);
	}

}
